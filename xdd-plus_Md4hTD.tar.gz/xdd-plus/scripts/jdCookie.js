
var cookies = {CookieJD1:'pt_key=AAJhwsL5ADBZqWNkxYRGezkPweX8P-rskb8Ytny92_TFxVksC_rZ-GFN-9QZAYbiWdf98yA3tyA;pt_pin=jd_mKovebCFCKLP;',CookieJD2:'pt_key=AAJhxWexADAU0pdrEnqjSxLL532iFqjg0JwsTntmUO-BIjYj8bScJ4sB6m5HMaMTVIm39rVcSSc;pt_pin=jd_AoBRXQupeuOJ;',CookieJD3:'pt_key=AAJhvzUTADDRoUc7-6Z2awdRX4_mIetYGZU7n3egBOEkc1tM65TDeLfAJs5BPIrD7lRP_LwbbhQ;pt_pin=jd_618e2bb541b83;',CookieJD4:'pt_key=AAJhsEigADDPU4a4sj2CI-NKyqwl_Oegw-S6EvtdSaYt6VI3DGudwPVLy2khY06m9G8cN8TFhss;pt_pin=HERO%E4%B8%B6PG;',CookieJD5:'pt_key=;pt_pin=jd_76d4dc7c7a9ba;',CookieJD6:'pt_key=AAJhxWuIADDWClln2zD0Ivrwa051NJs3zCk_kLuAOIIY4X2QTLdJsloy5lcHGy95Dun6ehhFljw;pt_pin=jd_5bbd7708175c9;',CookieJD7:'pt_key=AAJhqtPwADDSCORNGkCo8uOrvP0hns8oWgX5fW6HIcj3TMAIFY33MsWmr7IOTD5WEerqLSdHEa8;pt_pin=jd_693cd6889b6ed;',CookieJD8:'pt_key=AAJhqLEVADA8IoKcliDBnEAHTwz_ttEX6yVgkMu1ZqIUjMXk8O91Qsxk6dTVjLNVfWKzZ5aRtuI;pt_pin=jd_6e719001054ed;',CookieJD9:'pt_key=AAJhnu0KADA7YW-j8MsJdUb-fHrlfD9hSl0rrCEj_-tyV77FaS1MDozimhNpAbujtauc2afrCn8;pt_pin=jd_5c7ddefc74c56;',CookieJD10:'pt_key=AAJhnu32ADDP4U9XTG4wwL8x1olTpY3S_nyMCH5uWK9O4XuObze8x8waBSmBMEi5ZRXiA6QRP9M;pt_pin=jd_6fc4f3dec1b71;',CookieJD11:'pt_key=AAJhnvB8ADCDb7_OW0TSYdo1m4-HTp0F1ogAyIzwzweCERWsLgcWJM2TfLL1m8GYJz9U3OWKOJU;pt_pin=jd_7aad89715a7f6;',CookieJD12:'pt_key=AAJhqK_PADCYgQa2emJHKqU1U_ro24A1YCg4DRRq6dYaV9TVXVmXcDO0HsoMQ809WHk8AP5KdSg;pt_pin=jd_66e18a15bc529;',CookieJD13:'pt_key=AAJhtFDlADBMbcmpgctTArT9SsIxV02ROeAkVEgvT0LhjVcCmfDIJMcs22s-usJyBWziANiyTAs;pt_pin=wdXZIxMrddQEZx;',CookieJD14:'pt_key=;pt_pin=jd_6c4c41b5dabd9;',CookieJD15:'pt_key=AAJhqswbADDMrsaZkL_i_SgqZbJ0_TCZkroU1Bh8LHVSOSPywB9ddGRfNZvegb4mkC1OHGowl1s;pt_pin=jd_65c854963109d;',CookieJD16:'pt_key=;pt_pin=jd_rsScmmYXrRry;',CookieJD17:'pt_key=AAJhqiUkADDr5CFLJ8vkHj7wQ0gz7QFVkZXy87ECLSUYsVh8Xyqe-R5eywsYQl3PlUXWOw4AAFw;pt_pin=ywlpy;',CookieJD18:'pt_key=AAJht1cvADA9U6y5YJL1BqGxxKv1DG6FUWqDKF7Hq85rgHI97X-7VWMt2mnRlA7OW7m6HixpMDI;pt_pin=peiy163;',CookieJD19:'pt_key=AAJhvzgbADB6nAHexirh0O5aAS-KxrDDhdGaJKQtZ-D2JKWzzxNH2v4u2Kiho1ZjkBOfIKIsZDw;pt_pin=jd_7eed2a91bb8a5;',CookieJD20:'pt_key=AAJhvx2TADDVDKlRJVnINu4lSwfUHXD3vzbqQCohNAGztHDqxgj0xlGvwbobVhT3vUKekq3c3ns;pt_pin=jd_59acc82dd7d04;',CookieJD21:'pt_key=;pt_pin=jd_woiZOGdulGBk;',CookieJD22:'pt_key=;pt_pin=jd_ldqhOBwLCbOM;',CookieJD23:'pt_key=;pt_pin=jd_72c1d65989336;'}
var pins = process.env.pins
if(pins){
	pins = pins.split("&")
	for (var key in cookies) {
	    c = false
	    for (var pin of pins) {
		   if (pin && cookies[key].indexOf(pin) != -1) {
			  c = true
			  break
		   }
	    }
	    if (!c) {
		   delete cookies[key]
	    }
	}
}
module.exports = cookies