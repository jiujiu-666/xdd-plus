return reply(
     [
          `早上好`=>`好个锤子`
          `干饭了`=>`除了吃你还会什么？`
          `晚安`=>`早点睡 猪逼`
          <!--`扫码` => `发送pt_key=;pt_pin=; 这种格式给我，记得要;这个符号，提示很棒，即为成功，不要一直给我发消息，一分钟超过3条就会被自动拉黑。如果发送了CK但是我没回复你就是CK失效了。重新提取CK发给我。`-->
          `扫码` => `代挂地址http://jdwool.cn登录成功即代挂成功，每日自动任务，月约100-200红苞+若干京豆`
          `红包` => `https://raw.githubusercontent.com/jiujiu-666/xdd-plus/main/static/hb.jpg`
          `.*饭` => `美团外卖天天领红包点我领取多张美团外卖专享红包http://dpurl.cn/nuB81Gzz`
          `美腿` => `https://api.iyk0.com/mtt`
          `毒鸡汤`=>`https://www.hlapi.cn/api/djt?charset=utf-8&encode=text`
          `笑话`=>`https://www.hlapi.cn/api/gxdz`
          `妹妹` => `https://3650000.xyz/api/`
          `姐姐` => `http://3650000.xyz/random/?mode=66`
          `精神语录`=>`https://api.xcboke.cn/api/yulu?c=1002&encode=text`
          `网抑云`=>`https://api.xcboke.cn/api/yulu?c=1003&encode=text`
          `朋友圈文案`=>`https://api.xcboke.cn/api/yulu?c=1008&encode=text`
          `.*来对线`=>`https://api.xcboke.cn/api/yulu?c=1009&encode=text`
          `动漫台词`=>`https://api.xcboke.cn/api/yulu?c=2001&encode=text`
          `游戏台词`=>`https://api.xcboke.cn/api/yulu?c=2003&encode=text`
          `壁纸` => `http://api.btstu.cn/sjbz/?lx=dongman`
          `小清新` => `http://api.btstu.cn/sjbz/?lx=meizi`
          `.*美女` => `https://api.lyiqk.cn/purelady`
         `二次元图` => `https://acg.toubiec.cn/random.php`
         `.*换一个` => `http://api.btstu.cn/sjbz/?lx=m_dongman`
         `动漫头像` => `http://shengapi.cn/api/image/acgtx.php`
         `舔狗日记` => `http://shengapi.cn/api/tgrj.php`
         `.*骚话.*`=>`https://api.vvhan.com/api/sao`
         `文明` => `http://api.btstu.cn/sjbz/zsy.php`
          `富强` => `http://api.btstu.cn/sjbz/?m_lx=suiji`
          `和谐` => `https://api.btstu.cn/sjbz/api.php`
          `民主` => `https://cdn.seovx.com/?mom=302`
          `语录` => `https://api.ixiaowai.cn/ylapi/index.php`
          `舔狗` => `https://api.ixiaowai.cn/tgrj/index.php`
	  `.*一言.*`=>`https://api.ixiaowai.cn/ylapi/index.php`
         `更新` => `发送扫码或联系管理员绑定`
         `公告` => `呆瓜地址-> http://jdwool.cn/登录成功即代挂成功，每日自动任务，月约100-200红苞+若干京豆 输入"查询"`
         `密码` => `你猜`
         `教程` => `浏览器获取Cookie教程“https://docs.qq.com/doc/DQm5HUWFiZ2FZSUVR”`
         `密码` => `你猜`
        `菜单` => `
                京东菜单
       ———————————
            说明  丨  咨询
            打卡  丨  余额
            许愿
       ———————————
                娱乐菜单
       ———————————
            富强  丨 民主
            文明  丨 和谐
            妹妹  丨 美女
            风景  丨 壁纸
            你好  丨 美腿
            状态  丨 笑话
            骚话  丨 对线
       精神语录丨 毒鸡汤
       动漫台词丨 朋友圈文案
      ———————————
              管理员菜单
      ———————————
            状态  丨 升级
            重启  丨 转账
            删除  丨 通知
            执行  丨 优先级
            绑定  丨 命令
            导出  丨 助力
            回复  丨 屏蔽
            更新账号 |  清理过期账号
            取消屏蔽 |  任务列表
            设置管理员 | 取消管理员
      ———————————
              京东机器人
        `]
)